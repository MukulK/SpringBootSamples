package com.mukul.cloud.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@ConfigurationProperties(prefix = "jms")
public class ConnPropertiesConfiguration {
    private List<ConnProperty> properties;


    public List<ConnProperty> getProperties() {
        return properties;
    }

    public void setProperties(List<ConnProperty> properties) {
        this.properties = properties;
    }
}
