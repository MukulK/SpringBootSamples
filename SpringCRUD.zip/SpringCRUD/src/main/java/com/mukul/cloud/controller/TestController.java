package com.mukul.cloud.controller;
import com.mukul.cloud.configuration.ConnPropertiesConfiguration;
import com.mukul.cloud.configuration.ConnProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TestController {
    @Autowired
    private ConnPropertiesConfiguration connPropertiesConfiguration;

    @GetMapping("/properties")
    public List<ConnProperty> getProperties() {
        return connPropertiesConfiguration.getProperties();
    }
}
